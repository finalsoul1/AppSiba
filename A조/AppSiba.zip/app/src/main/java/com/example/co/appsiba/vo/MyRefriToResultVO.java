package com.example.co.appsiba.vo;

public class MyRefriToResultVO {

    String name;


    public MyRefriToResultVO() {
    }

    public MyRefriToResultVO(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
