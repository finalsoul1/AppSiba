package com.example.co.appsiba.vo;

public class SearchVO {

    private int id;
    private String name;
    private String small_image_location;
    private String ingredients;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSmall_image_location() {
        return small_image_location;
    }

    public void setSmall_image_location(String small_image_location) {
        this.small_image_location = small_image_location;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }
}
