package com.example.co.appsiba.recipe;

public class indgredients_item {
    private String indgredients_list;

    public indgredients_item(String indgredients_list) {
        this.indgredients_list = indgredients_list;
    }

    public String getIndgredients_list() {
        return indgredients_list;
    }

    public void setIndgredients_list(String indgredients_list) {
        this.indgredients_list = indgredients_list;
    }
}
