package app.siba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SibaappApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SibaappApiApplication.class, args);
	}
}
