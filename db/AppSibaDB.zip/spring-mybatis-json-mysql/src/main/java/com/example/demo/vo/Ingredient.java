package com.example.demo.vo;

import lombok.Data;

// 음식 재료
@Data
public class Ingredient {
	int id;
	String name;
}
