package com.example.demo;

import lombok.Data;

@Data
public class Row {
	String INFO_WGT;
	String INFO_ENG;
	String ATT_FILE_NO_MK;
	String RCP_PARTS_DTLS;
	
	String MANUAL01;
	String MANUAL02;	
	String MANUAL03;
	String MANUAL04;
	String MANUAL05;
	String MANUAL06;
	String MANUAL07;
	String MANUAL08;
	String MANUAL09;
	String MANUAL10;
	String MANUAL11;
	String MANUAL12;
	String MANUAL13;
	String MANUAL14;
	String MANUAL15;
	String MANUAL16;
	String MANUAL17;
	String MANUAL18;
	String MANUAL19;
	String MANUAL20;
	
	String INFO_PRO;
	String RCP_NM;
	String MANUAL_IMG03;

	String INFO_CAR;

	String RCP_WAY2;

	String RCP_PAT2;
	String HASHTAG;
	
	String MANUAL_IMG01;
	String MANUAL_IMG02;
	String MANUAL_IMG04;
	String MANUAL_IMG05;
	String MANUAL_IMG06;
	String MANUAL_IMG07;
	String MANUAL_IMG08;
	String MANUAL_IMG09;
	String MANUAL_IMG10;
	String MANUAL_IMG11;
	String MANUAL_IMG12;
	String MANUAL_IMG13;
	String MANUAL_IMG14;
	String MANUAL_IMG15;
	String MANUAL_IMG16;
	String MANUAL_IMG17;
	String MANUAL_IMG18;
	String MANUAL_IMG19;
	String MANUAL_IMG20;
	
	String RCP_SEQ;
	String ATT_FILE_NO_MAIN;
	String INFO_NA;
	String INFO_FAT;
	
}



