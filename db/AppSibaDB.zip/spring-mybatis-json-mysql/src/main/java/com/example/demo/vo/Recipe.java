package com.example.demo.vo;

import lombok.Data;

@Data
public class Recipe {
	int foodId;
	String imageLocation;
	String desc;
	int ord;
}
