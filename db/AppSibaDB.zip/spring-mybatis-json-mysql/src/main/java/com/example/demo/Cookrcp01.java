package com.example.demo;

import java.util.List;

import lombok.Data;

@Data
public class Cookrcp01 {
	Result result;
	String total_count;
	List<Row> row;

}
