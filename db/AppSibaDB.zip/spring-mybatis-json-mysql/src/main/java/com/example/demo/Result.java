package com.example.demo;

import java.util.List;

import lombok.Data;

@Data
public class Result {
	String msg;
	String code;
}
